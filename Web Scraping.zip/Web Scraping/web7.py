import requests
from bs4 import BeautifulSoup

class PriceTracer:
    def __init__(self, url):
        self.url = url
        self.headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                          "AppleWebKit/537.36 (KHTML, like Gecko) "
                          "Chrome/120.0 Safari/537.36"
        }
        response = requests.get(self.url, headers=self.headers)
        if response.status_code == 200:
            self.soup = BeautifulSoup(response.text, "lxml")
        else:
            self.soup = None

    def product_title(self):
        if not self.soup:
            return "Request failed"
        title = self.soup.find("span", {"id": "productTitle"})
        return title.get_text(strip=True) if title else "Title not found"

    def product_price(self):
        if not self.soup:
            return "Request failed"
        price = self.soup.find("span", {"id": "priceblock_ourprice"})
        if not price:
            price = self.soup.find("span", {"id": "priceblock_dealprice"})
        if not price:
            price = self.soup.find("span", {"class": "a-price-whole"})
        return price.get_text(strip=True) if price else "Price not found"

url = "https://www.amazon.in/dp/B0DSKL9MQ8"
device = PriceTracer(url)

print("Device Name:", device.product_title())
print("Device Price:", device.product_price())