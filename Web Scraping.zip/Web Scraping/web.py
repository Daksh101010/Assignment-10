import requests

url = "http://127.0.0.1:8000/hello/"

user = {
    "user-Agent" : 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36 Edg/143.0.0.0'
}

response = requests.get(url = url , headers = user)

print(response.request.headers)