import requests
import re
import os

def download_images(query, num_images=5):

    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                      "AppleWebKit/537.36 (KHTML, like Gecko) "
                      "Chrome/143.0.0.0 Safari/537.36"
    }

    url = f"https://www.google.com/search?q={query}&tbm=isch"

    response = requests.get(url, headers=headers)
    html = response.text

    pattern = r"https://[^\"']*\.jpg"
    image_urls = re.findall(pattern, html)

    if not os.path.exists("downloads"):
        os.makedirs("downloads")

    for i, img_url in enumerate(image_urls[:num_images], start=1):
        try:
            img_data = requests.get(img_url, headers=headers).content
            file_path = os.path.join("downloads", f"{query}_{i}.jpg")
            with open(file_path, "wb") as f:
                f.write(img_data)
            print(f"Downloaded: {file_path}")
        except Exception as e:
            print(f"Failed to download {img_url}: {e}")

if __name__ == "__main__":
    user = input("Enter the image name: ")
    download_images(user, num_images=5)