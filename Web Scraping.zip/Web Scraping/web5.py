import requests
from bs4 import BeautifulSoup

def extract(url):
    response = requests.get(url = url).content
    soup = BeautifulSoup(response , 'html.parser')
    tag = soup.find("div",id="mp-left")
    print(tag)

extract(url = "https://en.wikipedia.org/wiki/Main_Page")




